# Numbers in Sections 5.2 and 6 of report.tex: old vs. new

This covers every number in `report/report.tex` Sections 5.2 and 6, comparing the report as merged in `c0bb5ae` with the rerun on the fixed checkpoint. `report.tex` was not edited, so the "old" column is what the report currently says.

- **Old:** `blr.py` on the stale `data/processed/checkpoint_table.parquet` (1,521 / 331 / 1,479 innings at ball 1).
- **New:** `blr.py` on `load_splits()` after the 20-over fix (1,515 / 331 / 1,473 innings).
- **Source:** the `blr.py` line that computes the number, plus its row in `results/blr_summary.md`. Numbers marked **manual** are not written by any code; each one was checked against the rebuilt checkpoint or the raw Cricsheet JSON.
- **Rounding:** new values are rounded to the report's precision. Rows marked **CHANGED** need their text updated.

## Section 5.2 (Log score and squared error), lines 201–218

Section 5.2 has no empirical numbers, only definitions.

| line | number | old | new | source |
|---|---|---|---|---|
| 206 | bucket index j(y) = min(⌊y/10⌋, **40**), width **10** | same | same | `blr.py:55-56` (`bucket_of`), `blr.py:50` (`N_BUCKETS = 41`) |
| 208 | g = (g_0, …, g_**40**) | same | same | `blr.py:50` |

## Section 6.1 (Optimal score), lines 221–254

Section 6.1 also has no empirical numbers. One definition changed:

| line | text | status |
|---|---|---|
| 251 | "Plugging the empirical distribution of the test totals into H_S" | **Wording change needed.** The no-features optimum is now the entropy of the *bucketed* ECDF of test totals, spread uniformly within buckets like the model's forecasts (`blr.py:129-138`). Before, the RPS version used the integer-level ECDF. The log-score and MSE versions are unchanged. |

## Section 6.2 (Demo), prose

| line | number | old | new | source |
|---|---|---|---|---|
| 257 | features before ball 1 / afterward | 19 / 31 | 19 / 31 | `blr.py:162` → `n_features`. The unfixed checkpoint would have given 20 / 32 |
| 257 | batters at the crease with no previous T20I | 6–9% | 6–9% | **manual, verified with a caveat.** Career-average missingness pooled over all splits is 6.2% / 6.8% / 8.6% at overs 6 / 10 / 15. On train only, which is what the imputation sees, it is 8.9% / 9.6% / 11.3% |
| 257 | a0 = b0 | 0.01 | 0.01 | `blr.py:49` |
| 257 | τ² grid | {10⁻³, …, 10} | same | `blr.py:48` |
| 257 | τ² chosen | 0.1 at every checkpoint | 0.1 at every checkpoint | `blr.py:154` → `tau2` |
| 257 | training innings | about 1,500 | about 1,500 | `blr.py:162` → `n_train` 1,515 / 1,515 / 1,515 / 1,495 |
| 257 | degrees of freedom 2a_n | ≈ 1,500 | ≈ 1,500 | `blr.py:162` → `nu` 1,515.02 / 1,495.02 |
| 263 | sampler agreement / draws | 0.005 / 400,000 | same | `tests/test_blr.py:21`. This is the test's pass threshold, not a measured value; the test passes |
| 267 | venue, match | Kensington Oval, Bridgetown; 2024 final | same | **manual, verified**: `data/t20s_json/1415755.json` (2024-06-29) |
| 267 | India's total | 176/7 | 176/7 | **manual, verified**: 176 runs, 7 wickets in the JSON. 176 is also `actual` in the demo table |
| 267 | best estimate, ball 1 | 178 | **177** | **CHANGED.** `blr.py:169` → demo table 177.65 → 177.45 |
| 267 | P(170–179), ball 1 | 0.11 | 0.11 | demo table 0.1116 → 0.1117 |
| 267 | score after over 6 | 45/3 | 45/3 | demo table |
| 267 | best estimate / bucket / P, over 6 | 164 / 160–169 / 0.15 | 164 / 160–169 / 0.15 | demo table 164.23, 0.1478 |
| 267 | P(actual bucket), over 6 | 0.14 | 0.14 | demo table 0.1375 |
| 267 | score / best estimate, over 10 | 75/3 / 169 | 75/3 / 169 | demo table 168.74 |
| 267 | score / best estimate, over 15 | 118/4 / 171 | 118/4 / **172** | **CHANGED.** Demo table 171.46 → 171.55 |
| 267 | bucket / P, over 15 | 170–179 / 0.28 | 170–179 / 0.28 | demo table 0.2750 |
| 272 | actual total (caption) | 176 | 176 | demo table |
| 276 | skill, ball 1 / over 15 | 20% / 70% | 20% / 70% | `blr.py:163` → `skill` 0.2006 / 0.6978 |
| 276 | model-implied RPS vs no-features optimum, ball 1 | 20.2 vs 26.3 | 20.2 vs **26.4** | **CHANGED.** `rps_opt` (`blr.py:121`) 20.15; `marg_rps` (`blr.py:138`) 26.35 |
| 276 | same, over 15 | 8.1 vs 25.0 | 8.1 vs **25.1** | **CHANGED.** `rps_opt` 8.14; `marg_rps` 25.08 |
| 276 | "about 8 runs of RPS" | 8 | 8 | `rps_opt` 8.14 |
| 276 | RMSE after 15 overs | about 14 | about 14 | √`mse_opt` = √193.40 = 13.9 (`blr.py:98, 123`) |
| 313 | realized vs model-implied RPS, ball 1 | 21.3 vs 20.2 | **21.2** vs 20.2 | **CHANGED.** `rps` 21.24, `rps_opt` 20.15 |
| 313 | realized vs model-implied MSE, ball 1 | 1,451 vs 1,261 | **1,447** vs **1,260** | **CHANGED.** `mse` / `mse_opt` (`blr.py:123`) |
| 313 | mean underprediction, ball 1 | 4.3 runs | **4.6 runs** | **CHANGED.** `bias` (`blr.py:125`) 4.60 |
| 313 | "average test total is not higher than in training" | — | holds | **manual, verified**: 150.4 test vs 152.4 train (ball 1). The associate share is 45% in train and 80% in test |
| 313 | full-member totals, test vs train | 175 vs 162 | 175 vs 162 | **manual, verified**: 174.8 vs 162.0 |
| 313 | associate totals, test vs train | 144 vs 141 | 144 vs 141 | **manual, verified**: 144.3 vs 140.6 |
| 313 | intercept shrinkage share of the gap | about 1 run | about 1 run | **manual, verified**: refitting at ball 1 with an unpenalized intercept cuts the bias from 4.60 to 3.61 (0.999 runs). At overs 6 / 10 / 15 it accounts for 0.72 / 0.54 / 0.30 runs |
| 313 | realized vs model-implied, from over 6 on | within 7% | within 7% | derived from `rps`/`rps_opt`, `log`/`log_opt`, `mse`/`mse_opt`. The largest gap is RPS at over 15 (7.62 vs 8.14, −6.3%) |
| 313 | "slightly below" after overs 10 and 15 | holds | holds | all three scores are below `*_opt` at overs 10 and 15 |
| 313 | coverage of central 90% intervals | 91–92% | 91–92% | `cov90` (`blr.py:125`) 0.914 / 0.925 |
| 315 | bucket of ŷ contains y, ball 1 / over 15 | 11% / 27% | 11% / 27% | `hit` (`blr.py:124`) 0.113 / 0.272 |
| 315 | RMSE before ball 1 | 38 runs | 38 runs | √`mse` = √1,447.4 = 38.0 |
| 315 | test totals above the highest training total | Fifteen | Fifteen | `n_above_train_max` (`blr.py:166`) |
| 315 | highest training total | 263 | 263 | **manual, verified**: `max(final_total)` in train.parquet at every checkpoint |
| 315 | innings the empirical baseline gives probability zero | implied 15 | **19 / 19 / 19 / 27** | **FLAG: the text is incomplete.** `ecdf_n_zero_prob` (`blr.py:164`). All 15 totals above 263 are ≥ 271, so their buckets are empty. So are the buckets of 4 very low totals (10, 17, 18, 18), and of 12 totals under 50 at over 15. "Infinite log score" still holds |
| 315 | largest single log score | up to 12.6 nats | up to 12.6 nats | `log_max` (`blr.py:165`) 12.59 at over 6 |
| 315 | "about five times the average" | 5× | 5× | 12.59 / 2.42 = 5.2 (`log_max` / `log` at over 6) |

## Section 6.2, Table `tab:demo` (lines 278–311)

The source for every row is `results/blr_summary.md`, written at `blr.py:172-189`. Cells are ball 1 / over 6 / over 10 / over 15.

| line | row | old | new | blr_summary row, code |
|---|---|---|---|---|
| 288 | **Climatology** → rename to **ECDF baseline** | 26.56 / 26.56 / 26.46 / 25.21 | **26.57 / 26.57** / 26.46 / **25.22** | `ecdf_rps`, `blr.py:158-159` |
| 289 | BLR RPS | 21.27 / 15.17 / 11.85 / 7.63 | **21.24 / 15.13 / 11.80 / 7.62** | `rps`, `blr.py:121` |
| 289 | ± SE | 0.44 / 0.31 / 0.23 / 0.14 | 0.44 / 0.31 / 0.23 / 0.14 | `rps_se`, `blr.py:165` |
| 290 | Skill vs. climatology → **vs. ECDF baseline** | 0.20 / 0.43 / 0.55 / 0.70 | 0.20 / 0.43 / 0.55 / 0.70 | `skill`, `blr.py:163` |
| 291 | RPS optimum, no features | 26.29 / 26.29 / 26.20 / 25.01 | **26.35 / 26.35 / 26.26 / 25.08** | `marg_rps`, `blr.py:134-138` (now bucketed) |
| 292 | RPS optimum, model-implied | 20.16 / 15.26 / 12.43 / 8.12 | **20.15 / 15.27 / 12.45 / 8.14** | `rps_opt`, `blr.py:121` |
| 295 | BLR log score | 2.76 / 2.42 / 2.17 / 1.73 | 2.76 / 2.42 / 2.17 / 1.73 | `log`, `blr.py:122` |
| 296 | log optimum, no features | 2.95 / 2.95 / 2.94 / 2.90 | 2.95 / 2.95 / 2.94 / 2.90 | `marg_log`, `blr.py:138` |
| 297 | log optimum, model-implied | 2.69 / 2.41 / 2.20 / 1.76 | 2.69 / 2.41 / 2.20 / 1.76 | `log_opt`, `blr.py:122` |
| 300 | BLR MSE | 1,451 / 741 / 448 / 182 | **1,447 / 738 / 444** / 182 | `mse`, `blr.py:123` |
| 301 | MSE optimum, no features | 2,210 / 2,210 / 2,193 / 1,993 | 2,210 / 2,210 / 2,193 / **1,992** | `marg_mse`, `blr.py:138` |
| 302 | MSE optimum, model-implied | 1,261 / 716 / 471 / 193 | **1,260 / 718 / 473** / 193 | `mse_opt`, `blr.py:98, 123` |
| 305 | mean error y − ŷ | +4.3 / +0.7 / −1.1 / −0.9 | **+4.6** / +0.7 / −1.1 / **−1.0** | `bias`, `blr.py:125` |
| 306 | bucket of ŷ contains y | 0.11 / 0.16 / 0.19 / 0.27 | 0.11 / **0.17** / 0.19 / 0.27 | `hit`, `blr.py:124` |
| 307 | model-implied hit | 0.11 / 0.15 / 0.18 / 0.28 | 0.11 / 0.15 / 0.18 / 0.28 | `hit_opt`, `blr.py:124` |
| 308 | coverage of central 90% | 0.88 / 0.90 / 0.91 / 0.92 | 0.88 / 0.90 / 0.91 / 0.92 | `cov90`, `blr.py:125` |

## Wording to change when merging (report.tex was not edited)

1. **Line 199:** "climatological forecast that assigns every innings the empirical distribution of training totals". Change to "ECDF baseline", and say that it is bucketed like the model's forecasts.
2. **Line 251:** the no-features optimum is now the entropy of the bucketed ECDF of test totals.
3. **Line 276:** "beats climatology". Change to "beats the ECDF baseline".
4. **Line 280, the caption:** "Climatology is bucketed like the BLR forecasts". Change to "The ECDF baseline is …". "No features is the entropy of the empirical distribution of test totals" also needs "bucketed".
5. **Lines 288 and 290:** rename the rows.
6. **Line 315:** "The empirical climatology gives their buckets probability zero". Change to "the ECDF baseline", and give the full count: 19 test innings, or 27 after over 15.
7. **Outside Sections 5.2 and 6:** Table 1 (`tab:counts`, lines 103–106) still shows the stale counts. It should be 1,515 / 331 / 1,473; 1,515 / 331 / 1,473; 1,515 / 329 / 1,471; 1,495 / 324 / 1,433.
