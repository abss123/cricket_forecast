# BLR review: Thomas's merged work vs. the write-up

File paths in this folder mirror the repo, so `report/report.tex` compiles here with its figure and `arxiv.sty`. `report.tex` is the unedited merged version, so its numbers are the old ones. `numbers.md` lists every number in Sections 5.2 and 6 with its old value, new value and source.

## Status after fixes (2026-09-29, uncommitted)

| original finding | status |
|---|---|
| 1. BLR read the stale cache | **Fixed.** `blr.py` now calls `load_splits(cp)` and uses `final_total`. `build_checkpoint_table()` is no longer used |
| 2. The checkpoint's 8 recovered matches were featurized for 50 overs | **Fixed.** Details below the table |
| 3. The switch should change results only slightly | **Confirmed.** Ball-1 RPS is 21.27 → 21.24 and over-15 RPS is 7.63 → 7.62. τ² is still 0.1 and there are still 19 / 31 features. The full list is in `numbers.md` |
| 4. The committed results were not bit-reproducible | **Moot.** `results/blr_summary.md` and `report/figs/blr_demo.png` were regenerated here from the current checkpoint |
| e. Two different "climatology" baselines | **Fixed in blr.py and its outputs.** Details below the table |
| e. The report says 15 innings get zero probability; it is 19–27 | Now reported as the `ecdf_n_zero_prob` row: 19 / 19 / 19 / 27. The text at `report.tex:315` still needs updating |
| Table 1 (`tab:counts`) shows stale counts | **Not changed**, because report.tex is excluded. The correct values are in `numbers.md` |

**How finding 2 was fixed.** The new `scheduled_overs(info)` helper in `scripts/build_training_table.py` returns 20 for every men's T20I. It is used in three places:

- `build_match_info`, which feeds the features
- the training-table flags
- `first_innings_exclusion`

The per-bowler limit comes from the new `bowler_overs_remaining` helper in `src/features/state.py`: scheduled overs / 5, which is 4.

The only features that depend on scheduled overs are:

- `balls_remaining`
- `bowlers_with_overs_remaining`
- `remaining_bowling_economy_weighted`

The phase and run-rate windows use the current over number, not the scheduled overs.

**Checks on the rebuilt checkpoint:**

- Row counts are unchanged: 1,515 / 331 / 1,473 at ball 1 and 1,495 / 324 / 1,433 at over 15.
- Compared with the old checkpoint, only those three columns changed (32 / 5 / 27 cells), and only in the 8 matches.
- The new `tests/test_scheduled_overs.py` checks that:
  - `balls_remaining` is 120 at ball 1 for every row, and 120 − balls bowled at every checkpoint;
  - no bowler has more than 4 overs remaining at any checkpoint of any match;
  - a synthetic 50-over-labelled T20I gives 120 balls and 4 overs per bowler.

**How the baseline was fixed.**

- There is now one function, `ecdf_buckets` (`blr.py:129`). It gives the empirical distribution of totals, bucketed like the model's forecasts.
- It is used for the **ECDF baseline**, built from training totals: `ecdf_rps`, `skill` and `ecdf_n_zero_prob`.
- It is also used for the **no-features optimum** (`marginal_optimum`), built from test totals. Its RPS now uses the bucketed CDF: 26.29 → 26.35 at ball 1.
- The words "climatology" and "clim" no longer appear in blr.py or its outputs.
- `q5.py`, `forecasters.fit_climatology` and `results/summary.md` still use "climatology". They belong to the older LightGBM experiment and were not touched.

**Not rebuilt:** the old cache `data/processed/checkpoint_table.parquet` and the ball-by-ball table `train_1st_innings.parquet`. Both still contain the 50-over features and should be rebuilt before anything else uses them.

---

The rest of this file is the **original review, before the fixes**, and is kept for the record. It was checked at `main` = `671f6a2` against `c0bb5ae` (Thomas Lee, 2026-09-29).

## Headline findings (before the fixes)

1. **The BLR does not use the frozen checkpoint.** It reads the old cached `data/processed/checkpoint_table.parquet` (dated Sep 24). That cache predates both checkpoint commits. It still contains no-result matches, and it is missing the matches that the `info.overs = 50` fix brought back in. So every BLR number and Table 1 (`tab:counts`) are based on 1,521 / 331 / 1,479 innings, not 1,515 / 331 / 1,473.
2. **The frozen checkpoint has its own bug.** The 8 matches that the `overs = 50` fix brought back in still have `balls_remaining` computed from 50 overs (300 at ball 1). This affects 12 train rows and 20 test rows. If blr.py is pointed at `load_splits()` unchanged, `balls_remaining` is no longer constant and becomes a spurious extra feature (20 / 32 features instead of 19 / 31).
3. **The results change very little after switching data.** For example, ball-1 RPS goes from 21.27 to 21.25 and over-15 RPS from 7.63 to 7.62 (table in §a). The text and tables still need to be regenerated.
4. **The committed results are not exactly reproducible here.** Re-running the current blr.py on the local cache gives RPS 21.2756 against 21.2713 in `blr_summary.md`. The climatology and no-feature numbers match exactly, so the target data is the same. The difference is probably in Thomas's local cache features or his BLAS/numpy versions. It is at most about 0.005 RPS and 0.6 MSE.

---

## a. Data loading and row counts

**No, blr.py does not call `load_splits()`.** It uses the old cache and splits by calendar year itself:

- `blr.py:29`: `from src.experiments.checkpoints import CHECKPOINT_ORDER, build_checkpoint_table`
- `blr.py:135-137`: `df = build_checkpoint_table()`, then `split = np.select([year <= 2022, year == 2023], ["train", "val"], "test")`
- `checkpoints.py:152-153`: `build_checkpoint_table()` returns `data/processed/checkpoint_table.parquet` whenever that file exists, and it never rebuilds it.
- `load_splits()` (`checkpoints.py:247`) reads `data/checkpoints/first_innings/`. No experiment code calls it; the only other place it appears is `tests/test_first_innings_splits.py`.

**Test row counts in `blr_summary.md`: not reported.** The summary gives no n. Two things can be inferred from it:

- **Train n**, from `nu = 2·a_n = 2·a0 + n = n + 0.02`: 1,521 / 1,521 / 1,521 / 1,501. The current checkpoint has 1,515 / 1,515 / 1,515 / 1,495.
- **Test n**, obtained by re-running the split on the cache: 1,479 / 1,479 / 1,477 / 1,439. The current checkpoint has 1,473 / 1,473 / 1,471 / 1,433. These cache counts are also the numbers in `report.tex:103-106` and in `results/split_row_counts.csv`, which is written by `q5.py`, also from the cache.

**Why the cache differs from the checkpoint** (checked by match ID):

| | train | val | test | cause |
|---|---|---|---|---|
| in cache, not in checkpoint | 9 | 0 | 11 | no-results. `write_split_checkpoint` drops them (`checkpoints.py:218`, added in `59f6ef5`); the cache keeps them |
| in checkpoint, not in cache | 3 | 0 | 5 | matches whose Cricsheet file has `info.overs = 50`. They were excluded as "reduced_overs" until `5e1f82b` |
| net | 1,521 − 9 + 3 = **1,515** | 331 | 1,479 − 11 + 5 = **1,473** | |

**Bug in the frozen checkpoint (it affects the switch).** The `5e1f82b` fix only patched `first_innings_exclusion`. `compute_features` still takes `scheduled_overs` from `match_info` (`state.py:83-84`), so those 8 matches have the following `balls_remaining` values:

| checkpoint | ball 1 | over 6 | over 10 | over 15 |
|---|---|---|---|---|
| expected | 120 | 84 | 60 | 30 |
| actual | 300 | 264 | 240 | 210 |

The affected match IDs are:

- train: 894293, 1213874, 1213875
- test: 1448360, 1448362, 1473145, 1473146, 1473147

`remaining_bowling_economy_weighted` is probably wrong for the same matches, since the per-bowler cap is overs/5 (`state.py:37`). This needs a fix in `build_match_info` / `compute_features` and a regenerated checkpoint before the BLR moves over.

**Impact of switching.** Current blr.py, run in memory, on the cache and on `load_splits()` as it is today (bug included):

| | ball 1: cache → frozen | over 6 | over 10 | over 15 |
|---|---|---|---|---|
| n (train/val/test) | 1521/331/1479 → 1515/331/1473 | same as ball 1 | 1521/329/1477 → 1515/329/1471 | 1501/324/1439 → 1495/324/1433 |
| n_features | 19 → 20 | 31 → 32 | 31 → 32 | 31 → 32 |
| τ² | 0.1 → 0.1 | 0.1 → 0.1 | 0.1 → 0.1 | 0.1 → 0.1 |
| RPS | 21.28 → 21.25 | 15.17 → 15.14 | 11.85 → 11.80 | 7.63 → 7.62 |
| climatology RPS | 26.56 → 26.57 | 26.56 → 26.57 | 26.46 → 26.46 | 25.21 → 25.22 |
| skill | 0.199 → 0.200 | 0.429 → 0.430 | 0.552 → 0.554 | 0.697 → 0.698 |
| mean error (bias) | +4.37 → +4.59 | +0.67 → +0.65 | −1.11 → −1.12 | −0.92 → −0.96 |
| test totals > train max (263) | 15 → 15 | 15 | 15 | 15 |

## b. How bucket probabilities are computed

**Yes, they are closed-form Student-t CDF differences.** No sampling is used for the reported results. The code is `forecast()`, `blr.py:81-96`:

```python
nu    = 2 * an
yhat  = score + X @ mn                                   # location of Y = s + R
scale = sqrt(bn / an * (1 + x' Vn x))
tops  = 9, 19, ..., 399                                  # top total of buckets 0..39
S     = t.sf((tops + 0.5 - yhat) / scale, nu)            # P(Y > top_j)
S[tops < score] = 1.0                                    # buckets entirely below s: P(Y > top) = 1
p     = -diff(S, prepend=1, append=0)                    # p_j = P(Y > top_{j-1}) - P(Y > top_j); p_40 = P(Y > 399)
```

This matches report Eq. `tcdf` (`report.tex:259-263`). It uses `sf` rather than `1 − cdf`, so far upper-tail buckets don't underflow to zero.

**Negative remaining runs.** The model is Y = s + max(0, round(R)). For an integer t ≥ s, Y ≤ t exactly when R < t − s + ½, so the CDF at t includes all mass with R < 0. That mass therefore lands at Y = s, in the bucket that contains the current score. For t < s the CDF is forced to 0 by `S[tops < score] = 1`, so buckets entirely below s get probability exactly 0. No probability is lost or renormalized; it is moved onto Y = s. This is consistent with step 3 of the sampler in `report.tex:138`.

**Things the truncation does not affect:**

- The best estimate `yhat = s + x'm_n` (`blr.py:90`)
- The MSE optimum `var = scale² ν/(ν−2)` (`blr.py:96`)

Both are computed on the untruncated, unrounded R, as the report says (`report.tex:252, 265`).

**Check.** `tests/test_blr.py` compares `forecast` with the Monte Carlo `sample_buckets` (400,000 draws, max abs difference < 0.005). One of its cases has a mean near 0, so the clamp is exercised. The test also checks that buckets below s are exactly 0 and every bucket above is > 0. **It passes here** (`1 passed`).

## c. Prior

The prior is defined at `blr.py:46-47` and `blr.py:74-78`.

| | value | source |
|---|---|---|
| m0 | **0** (the vector) | implicit in `posterior()`: `mn = Vn @ (X.T @ r)` drops the `V0⁻¹ m0` term |
| V0 | **τ² I**, which **includes the intercept** | `np.eye(p) / tau2` |
| a0 | **0.01** | `A0 = B0 = 0.01` |
| b0 | **0.01** | same |
| τ² grid | **{1e-3, 1e-2, 1e-1, 1, 10}** | `TAU2_GRID` |
| selection rule | minimize mean validation (2023) RPS of the bucketed CDF | `blr.py:151` |
| τ² chosen | **0.1 at all four checkpoints** | `blr_summary.md` row `tau2`; also 0.1 on the frozen data |

Notes:

- `b_n` uses the shortcut `r'r − m_n'X'r`, which is valid only because m0 = 0 (`V_n⁻¹m_n = X'r`). The test checks this against the direct residual form (`test_blr.py:15`).
- The features are standardized, but r is not centered, so τ² = 0.1 shrinks the intercept (≈ 60–150 runs of remaining total) toward 0. The report mentions this (`report.tex:313`, "about 1 run of the gap"). No code produces that "1 run" number.
- τ² = 0.1 is an interior point of the grid at every checkpoint, so the grid is not the constraint.

## d. Features

**The declared list** is at `blr.py:36-45`. It has 25 numeric and 3 categorical features:

- **Match state:** `score, wickets, balls_remaining, run_rate_last_5, partnership_runs`
- **Batters at the crease:** `striker_runs, striker_strike_rate, non_striker_runs, non_striker_strike_rate`, and `striker_career_avg_t20i, striker_career_sr_t20i, non_striker_career_avg_t20i, non_striker_career_sr_t20i`
- **Batting and bowling resources:** `remaining_batting_order_sr, remaining_batting_order_avg, remaining_bowling_economy_weighted`
- **Elo:** `elo_batting, elo_bowling, elo_diff, elo_n_batting, elo_n_bowling`
- **Form:** `team_batting_recent_form, team_bowling_recent_form`
- **Venue:** `venue_avg_first_innings_score, venue_n_prior_matches`
- **Categorical, one-hot, all levels kept:** `batting_team_tier` {associate, full}, `bowling_team_tier` {associate, full}, `home_away` {away, home, neutral}

**Processing** (`make_design`, `blr.py:57-71`):

- Columns are one-hot encoded with `pd.get_dummies` (no level dropped). Any column whose train SD is 0 or NaN is dropped.
- The remaining columns are z-scored with train mean and SD.
- NaN is set to 0, which is mean imputation, with no missingness flags.
- An intercept column of 1s is prepended.

**Features used, checked on the cache:**

- **Ball 1: 19 features.** 13 are dropped: `score, wickets, balls_remaining, run_rate_last_5, partnership_runs`, the 4 in-innings batter stats and the 4 batter career stats (openers are unknown before ball 1). The 19 kept are the 3 resources, 5 Elo, 2 form, 2 venue and 7 dummies.
- **Overs 6, 10 and 15: 31 features.** Only `balls_remaining` is dropped.

**Interaction terms: none.** There are no products, squares, splines or checkpoint-specific transforms anywhere in blr.py. The model is linear in the columns above. This matters because `report.tex:152` says that nonlinear effects "such as the interaction between wickets in hand and balls remaining, must be supplied as explicit features". None are supplied. Balls remaining is constant within a checkpoint anyway, so that particular interaction only varies across checkpoints, which the separate model per checkpoint already covers.

**Smaller mismatches with the text:**

- The Elo difference is exactly collinear with the two ratings, and each full set of dummies is collinear with the intercept. The report acknowledges this at `report.tex:257`; the prior keeps V_n invertible. The RuntimeWarnings (divide / overflow in matmul) printed on this machine come from numpy's Accelerate BLAS. Results are finite.
- The report says 6–9% of batters at the crease have missing career stats (`report.tex:257`). On the train cache I get 7.3–9.1% after over 6, rising to 8.8–11.7% after over 15. No code computes the figure in the report.

## e. Every occurrence of "climatology" / "climatological"

The search was case-insensitive over the repo, excluding `.venv`, `cricket_env`, `.git` and `data/`.

**report/report.tex (current)**

| line | context |
|---|---|
| 199 | Section 5.1: skill score `1 − RPS/RPS_clim` "relative to a **climatological** forecast that assigns every innings the empirical distribution of training totals" |
| 276 | Section 6.2: "The model beats **climatology** in RPS by 20% before ball 1 and by 70% after over 15." |
| 280 | Caption of `tab:demo`: "**Climatology** is bucketed like the BLR forecasts." |
| 288 | `tab:demo` row "**Climatology** & 26.56 & 26.56 & 26.46 & 25.21" |
| 290 | `tab:demo` row "Skill vs. **climatology** & 0.20 & 0.43 & 0.55 & 0.70" |
| 315 | Section 6.2: "The empirical **climatology** gives their buckets probability zero, so its log score is infinite" |

**report/archive/report.tex (the old draft, archived in c0bb5ae):** lines 91, 168, 174, 175, 186, 194, 202, 261, 263, 297.

**results/**

- `results/summary.md:19`: heading "skill vs. climatology"
- `results/summary.md:23`: row "Climatology 26.52 [25.38, 27.64] …"
- `results/summary.md:61`: "…run-rate forecaster collapses to climatology…"
- `results/summary.md:67`: "…Skill vs. climatology *grows*…"
- `results/blr_summary.md`: the word does not appear; the only related label is the row name `clim_rps`.

**Code**

- `src/experiments/blr.py`: the word does not appear. The code uses `clim`, `clim_rps` (`:155-156, :159`).
- `src/experiments/q5.py`: lines 9, 35, 55, 57, 65, 131, 132, 134, 159, 173, 273, 279, 297, 301, 303, 339, 341.
- `src/experiments/forecasters.py`: lines 7, 104, 108 (`fit_climatology`).

**Code output**

- `blr.py` prints only `wrote …/blr_summary.md`.
- `q5.py` writes `results/summary.md` (listed above).
- I could not search `report/T20_forecasting_report.pdf`, because no PDF text tool is installed here. It is built from `report.tex`.

**Two climatologies disagree.** In blr.py, climatology is the train-total distribution bucketed and then spread uniformly across each bucket (`blr.py:155-156`), which gives 26.56 at ball 1. In q5.py / `forecasters.fit_climatology`, it is the integer-level empirical CDF, which gives 26.52 in `results/summary.md`. The caption at line 280 flags the bucketing; line 199 does not.

**Line 315 claim.** The code never computes the climatology log score. I checked the claim directly:

- All 15 totals above 263 are ≥ 271. That makes their buckets empty in training, so the claim holds. It would have failed if any had fallen in 264–269.
- There are also 4 low totals at ball 1 (10, 17, 18, 18) and 12 at over 15 whose buckets are empty in training.
- So "infinite" is right, but 19–27 innings get zero probability, not 15.

## f. Section 5.2 (log score) and Section 6.1 (entropy bounds)

**Section 5.2 (`report.tex:201-218`) computes nothing numerically.** It defines two scores:

- The bucket log score LS = −log p_j(y) with j(y) = min(⌊y/10⌋, 40), and its expectation as cross-entropy = H(g) + KL(g‖p).
- The squared error of the best estimate, whose expectation is bias² + Var.

There are no numbers in 5.2. Its definitions are implemented here:

| quantity | code |
|---|---|
| j(y) | `bucket_of`, `blr.py:53-54`: `min(y // 10, 40)` |
| LS per innings | `scores()`, `blr.py:120`: `"log": -np.log(p[i, j])` |
| squared error | `blr.py:121`: `"mse": (y - yhat) ** 2` |

**Section 6.1 (`report.tex:221-254`) contains no numbers either.** It sets up:

- the entropy/divergence split (Eq. `entdiv`, Table `tab:entropy`);
- Jensen's bound R\*_S ≤ H_S(G);
- two estimators of the optimum: "no features" and "model-implied".

The numbers appear in Section 6.2's `tab:demo` (`report.tex:278-311`) and in the prose at lines 276, 313 and 315. Each maps to a row of `results/blr_summary.md`:

| report quantity (tab:demo row) | blr_summary.md row | code |
|---|---|---|
| RPS, model-implied (20.16 / 15.26 / 12.43 / 8.12) | `rps_opt` | `blr.py:119`: mean over innings of Σ_t F(t)(1−F(t)), with F the **bucketed** CDF |
| Log score, model-implied (2.69 / 2.41 / 2.20 / 1.76) | `log_opt` | `blr.py:120`: `special.entr(p).sum(1)` = H(p̂_i), averaged |
| MSE, model-implied (1,261 / 716 / 471 / 193) | `mse_opt` | `blr.py:96,121`: Student-t predictive variance scale²·ν/(ν−2) of the **untruncated** R |
| Bucket hit, model-implied (0.11 / 0.15 / 0.18 / 0.28) | `hit_opt` | `blr.py:122`: p̂_i at the bucket of round(ŷ) |
| RPS, no features (26.29 / 26.29 / 26.20 / 25.01) | `marg_rps` | `marginal_optimum`, `blr.py:129,131`: Σ_t G(t)(1−G(t)) with G the **integer-level** empirical CDF of **test** totals |
| Log score, no features (2.95 / 2.95 / 2.94 / 2.90) | `marg_log` | `blr.py:130-131`: H of the empirical **bucket** frequencies of test totals |
| MSE, no features (2,210 / 2,210 / 2,193 / 1,993) | `marg_mse` | `blr.py:131`: `y.var()` (ddof = 0) of test totals |
| BLR realized RPS / LS / MSE, ± SE, bias, hit, cov90 | `rps`, `rps_se`, `log`, `mse`, `bias`, `hit`, `cov90` | `blr.py:119-123, 160` |
| Climatology RPS, skill | `clim_rps`, `skill` | `blr.py:155-159` |

**Prose numbers that come from code output:**

- 20% / 70% skill
- 20.2 vs 26.3 and 8.1 vs 25.0
- RMSE ≈ 14 (√192.8) and 38 (√1,451)
- 12.6 nats (`log_max`, over 6)
- "about five times the average" (12.58 / 2.42 = 5.2)
- "Fifteen test totals" (`n_above_train_max`)
- 2a_n ≈ 1,500 (`nu`)
- the worked-example numbers at line 267: 178, 0.11, 164, 0.15, 0.14, 169, 171, 0.28 (from the demo table)

**Prose numbers that no code in the repo writes out:**

| claim | where | status |
|---|---|---|
| highest training total 263 | line 315 | I confirmed it from the cache |
| full members 175 vs 162, associates 144 vs 141 | line 313 | I confirmed from the cache: 174.8 / 161.9, 144.5 / 140.8 |
| "about 1 run of the gap" from intercept shrinkage | line 313 | not verified |
| "within 7%" | line 313 | consistent with the table |
| India 176/**7** | line 267 | the wicket count is not in the output |
| missing career stats 6–9% | line 257 | see §d |

**Things to watch in the 6.1 estimators:**

1. **The RPS columns use different CDFs.** The model-implied and climatology RPS use the bucketed CDF (uniform within each bucket), while the no-feature optimum uses the integer-level CDF. The log-score pair is consistent, since both are on buckets. The RPS difference is probably small, but the caption only says the climatology is bucketed.
2. **"No features" is fit in-sample on the test totals.** The plug-in entropy is biased downward: ×(n−1)/n for RPS (the archived draft proved this) and about (K−1)/2n ≈ 0.01 nats for the log score. Both are negligible at n ≈ 1,450, and "up to sampling error" (line 251) covers them.
3. **The model-implied MSE ignores truncation and rounding.** This is stated at line 252. Rounding adds about 1/12 run², which is negligible.
